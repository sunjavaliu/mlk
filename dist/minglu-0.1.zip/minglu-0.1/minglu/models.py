#coding=utf8
from django.db import models

# Create your models here.

class ssdata(models.Model):
    '''
    title = models.CharField(max_length = 150)
    content = models.TextField()
    timestamp = models.DateTimeField()
    '''
    
    zch = models.TextField()
    mcyename = models.TextField()
    fddbri = models.TextField()
    zyxmlb = models.TextField()
    dz = models.TextField()
    rjzczb = models.TextField()
    qylx = models.TextField()
    clrq = models.TextField()
    yyqx = models.TextField()
    hzrq = models.TextField()
    djjg = models.TextField()
    zt = models.TextField()
    jyfw = models.TextField()
    
    def __unicode__(self):
        return self.name
    
    class Meta:
        db_table = 'ssjibenxinxi'   #指定表名
        ordering = ['-hzrq']        #按核准日期排序
        