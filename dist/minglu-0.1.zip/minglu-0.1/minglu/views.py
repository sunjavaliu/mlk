#coding=utf8
from django.shortcuts import render
from django.template import loader,Context
from django.http import HttpResponse
from minglu.models import ssdata
from django.core.paginator import Paginator

# Create your views here.
#def archive(request):
    #posts = BlogPost.objects.all()
    #t = loader.get_template('archive.html')
    #c = Context({'posts': posts})
    #return HttpResponse(t.render(c))
    
def show(request):
    #data=ssdata.objects.all()[:10]
    
    data=ssdata.objects.exclude(qylx__icontains="个体")[:20]

    
    t = loader.get_template('index.html')
    c = Context({'posts': data})
    #return HttpResponse(u"欢迎光临 自强学堂!")
    return HttpResponse(t.render(c))
'''
    p = Paginator(data , 3)

    page = request.GET.get('page') # Get page

    try:

        contacts = p.page(page)

    except PageNotAnInteger: 

        contacts = p.page(1)

    except EmptyPage: 

        contacts = p.page(p.num_pages)

    #return render_to_response('blog_list.html', {"contacts": contacts})
'''
